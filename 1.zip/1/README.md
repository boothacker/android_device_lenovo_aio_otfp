Lineage-15.0 device tree for Lenovo K3-Note (aio_otfp)
